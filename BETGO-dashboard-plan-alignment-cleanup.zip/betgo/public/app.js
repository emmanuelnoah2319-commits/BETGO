const $ = (selector) => document.querySelector(selector);
$('#year').textContent = String(new Date().getFullYear());

async function request(url, options = {}) {
  const response = await fetch(url, { credentials: 'same-origin', ...options, headers: { ...(options.headers || {}) } });
  if (response.status === 204) return null;
  const body = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(body?.error?.message || 'Request failed');
  return body;
}
async function csrf() { return request('/api/csrf'); }
async function mutate(url, method, data) {
  const { csrfToken } = await csrf();
  const headers = { 'X-CSRF-Token': csrfToken };
  const options = { method, headers };
  if (data !== undefined) { headers['Content-Type'] = 'application/json'; options.body = JSON.stringify(data); }
  return request(url, options);
}
function showLogin(message = '') {
  $('#login-panel').hidden = false; $('#dashboard').hidden = true;
  $('#login-error').hidden = !message; $('#login-error').textContent = message;
}
function showMessage(id, message = '', isError = false) {
  const node = document.getElementById(id); if (!node) return;
  node.textContent = message;
  node.classList.toggle('form-error', isError); node.classList.toggle('form-success', Boolean(message) && !isError); node.hidden = !message;
}
function element(tag, className, text) {
  const node = document.createElement(tag); if (className) node.className = className;
  if (text !== undefined) node.textContent = text; return node;
}
async function loadPlans() {
  try {
    const { plans } = await request('/api/plans'); const select = $('#application-bookmaker');
    for (const option of select.options) {
      const plan = plans.find((item) => item.bookmaker === option.value);
      if (plan) option.textContent = `${plan.bookmaker} — ₦${Number(plan.priceNgn).toLocaleString('en-NG')} / ${plan.durationDays} days`;
    }
  } catch { /* Keep visible defaults if plans are temporarily unavailable. */ }
}
async function loadApplications() {
  const { applications } = await request('/api/admin/applications'); const list = $('#applications-list'); list.replaceChildren();
  if (!applications.length) { list.append(element('p', 'empty-state', 'No applications yet.')); return; }
  for (const item of applications) {
    const card = element('article', 'account-card');
    card.append(element('strong', '', item.fullName), element('p', '', item.email), element('p', 'fixture-meta', `${item.bookmaker} · ₦${Number(item.priceNgn).toLocaleString('en-NG')} / 30 days · ${item.status}`));
    if (item.status === 'pending') {
      const actions = element('div', 'account-actions');
      const approve = element('button', '', 'Approve & send payment link'); approve.type = 'button';
      approve.addEventListener('click', async () => {
        approve.disabled = true;
        try { const result = await mutate(`/api/admin/applications/${encodeURIComponent(item.id)}/approve`, 'POST', {}); showMessage('applications-message', result.message); await loadApplications(); }
        catch (error) { showMessage('applications-message', error.message, true); approve.disabled = false; }
      });
      const reject = element('button', 'button-secondary', 'Reject'); reject.type = 'button';
      reject.addEventListener('click', async () => {
        const reason = window.prompt('Enter the reason for rejecting this application:');
        if (!reason || reason.trim().length < 3) return;
        reject.disabled = true;
        try { const result = await mutate(`/api/admin/applications/${encodeURIComponent(item.id)}/reject`, 'POST', { reason: reason.trim() }); showMessage('applications-message', result.message); await loadApplications(); }
        catch (error) { showMessage('applications-message', error.message, true); reject.disabled = false; }
      });
      actions.append(approve, reject); card.append(actions);
    }
    list.append(card);
  }
}
async function loadDashboard() {
  try {
    const { user } = await request('/api/me'); $('#welcome').textContent = `Signed in as ${user.email}`;
    $('#login-panel').hidden = true; $('#dashboard').hidden = false; $('#dashboard-error').hidden = true;
    $('#admin-applications-section').hidden = user.role !== 'owner';
    $('#member-subscription-panel').hidden = user.role === 'owner';
    $('#member-home-panel').hidden = user.role === 'owner';
    if (user.role !== 'owner') {
      $('#member-bookmaker').textContent = user.bookmaker || 'Not assigned';
      const expiry = user.subscriptionExpiresAt ? new Date(user.subscriptionExpiresAt) : null;
      $('#member-expiry').textContent = expiry && !Number.isNaN(expiry.getTime()) ? expiry.toLocaleDateString() : 'Not available';
      const days = expiry ? Math.max(0, Math.ceil((expiry.getTime() - Date.now()) / 86400000)) : null;
      $('#member-days-left').textContent = days === null ? 'Contact support if this looks incorrect.' : days === 0 ? 'Subscription expired' : `${days} day${days === 1 ? '' : 's'} remaining`;
    }
    $('#password-change-panel').hidden = !user.mustChangePassword;
    if (user.mustChangePassword) return;
    if (user.role === 'owner') await loadApplications();
  } catch (error) {
    if (error.message === 'Login required' || error.message.includes('Session')) return showLogin();
    $('#dashboard-error').hidden = false; $('#dashboard-error').textContent = error.message;
  }
}
$('#login-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const button = $('#login-button'); button.disabled = true; button.textContent = 'Signing in…'; $('#login-error').hidden = true;
  try { await mutate('/api/auth/login', 'POST', { email: $('#email').value, password: $('#password').value }); $('#password').value = ''; await loadDashboard(); }
  catch (error) { showLogin(error.message); }
  finally { button.disabled = false; button.innerHTML = 'Sign in <span aria-hidden="true">→</span>'; }
});
$('#application-form').addEventListener('submit', async (event) => {
  event.preventDefault(); const button = $('#application-button'); button.disabled = true; button.textContent = 'Submitting…'; showMessage('application-message');
  try { const result = await mutate('/api/applications', 'POST', { fullName: $('#application-name').value.trim(), email: $('#application-email').value.trim(), bookmaker: $('#application-bookmaker').value }); $('#application-form').reset(); showMessage('application-message', result.message); }
  catch (error) { showMessage('application-message', error.message, true); }
  finally { button.disabled = false; button.textContent = 'Submit application'; }
});
$('#refresh-applications').addEventListener('click', async () => {
  try { await loadApplications(); showMessage('applications-message', 'Applications refreshed.'); }
  catch (error) { showMessage('applications-message', error.message, true); }
});
$('#password-change-form').addEventListener('submit', async (event) => {
  event.preventDefault();
  try { const result = await mutate('/api/me/password', 'POST', { currentPassword: $('#temporary-password').value, newPassword: $('#new-password').value }); showMessage('password-change-message', result.message); await mutate('/api/auth/logout', 'POST'); showLogin('Password changed. Sign in with your new password.'); }
  catch (error) { showMessage('password-change-message', error.message, true); }
});
$('#logout-button').addEventListener('click', async () => {
  try { await mutate('/api/auth/logout', 'POST'); showLogin(); }
  catch (error) { $('#dashboard-error').hidden = false; $('#dashboard-error').textContent = error.message; }
});
loadPlans();
loadDashboard();
